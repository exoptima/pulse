#!/usr/bin/env bash
sudo rm -rf /home/ubuntu/*
tar xzvf build.tar.gz
